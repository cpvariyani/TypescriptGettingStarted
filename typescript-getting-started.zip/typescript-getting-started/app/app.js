function ShowProject() {
    document.getElementById('divMessage').innerText = 'Tools Optimization';
}
